import streamlit as st

st.set_page_config(layout="wide")

st.title("RoadKeeper")
st.write("왼쪽 메뉴에서 페이지를 선택하세요.")
