import streamlit as st
import mysql.connector

st.title("FAQ")

col1, col2 = st.columns([3, 1])

with col1:
    brand = st.selectbox(
        "사이트 / 브랜드 선택",
        ["전체", "환경부", "경기도청", "서울특별시", "부산광역시"]
    )

with col2:
    keyword = st.text_input("검색어")
    

def get_connection():
    connection = mysql.connector.connect(
        host="localhost",
        user="ohgiraffers",
        password="ohgiraffers",
        database="roadkeeperdb",
        charset="utf8mb4"
    )
    return connection

def get_faq_list():
    connection = get_connection()
    # SQL 수행을 위한 cursor 객체 생성
    cursor = connection.cursor()

    # sql = "SELECT * FROM tbl_menu"
    sql = "SELECT * FROM tbl_FAQ"

    # SQL 수행
    cursor.execute(sql)

    # fetchall() 메서드를 이용해 조회 결과 반환
    result_rows = cursor.fetchall()

    # print(result_rows)
    for row in result_rows:
        print(row)

    # cursor 및 연결 객체 자원 반납
    cursor.close()
    connection.close()
    return result_rows


faq_list = get_faq_list()

st.divider()

if not faq_list:
    st.info("FAQ가 없습니다.")
else:
    for faq_id, q, a, b in faq_list:
        with st.expander(f"Q. {q}"):
            st.write(a)
            st.caption(f"출처: {b}")
