import pandas as pd
from db.db_connect import get_connection


def fetch_faq(inst_name: str) -> pd.DataFrame:
    """
    FAQ 데이터를 기관명으로 조회
    inst_name == '전체' 이면 전체 조회
    """
    conn = get_connection()

    if inst_name == "전체":
        query = """
            SELECT FAQ_CODE, QUESTION, ANSWER, INST_NM
            FROM TBL_FAQ
            ORDER BY FAQ_CODE
        """
        df = pd.read_sql(query, conn)
    else:
        query = """
            SELECT FAQ_CODE, QUESTION, ANSWER, INST_NM
            FROM TBL_FAQ
            WHERE INST_NM = %s
            ORDER BY FAQ_CODE
        """
        df = pd.read_sql(query, conn, params=[inst_name])

    conn.close()
    return df
