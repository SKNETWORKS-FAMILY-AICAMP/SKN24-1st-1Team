import mysql.connector
from mysql.connector import Error

def get_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="ohgiraffers",
            password="ohgiraffers",
            database="roadkeeperdb",
            charset="utf8mb4"
        )

        if connection.is_connected():
            return connection

    except Error as e:
        print(f"[DB ERROR] {e}")
        return None


connection = get_connection()
print(connection.is_connected())


# SQL 수행을 위한 cursor 객체 생성
cursor = connection.cursor()

# sql = "SELECT * FROM tbl_menu"
sql = "SELECT * FROM tbl_faq"

# SQL 수행
cursor.execute(sql)

# fetchall() 메서드를 이용해 조회 결과 반환
result_rows = cursor.fetchall()

# print(result_rows)
for row in result_rows:
    print(row)

# cursor 및 연결 객체 자원 반납
cursor.close()
connection.close()