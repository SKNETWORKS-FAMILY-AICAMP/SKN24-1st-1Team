import streamlit as st

st.title("자주 묻는 질문(FAQ)")

# -----------------------------
# 상단: SELECT + 오른쪽 검색 버튼
# -----------------------------
col1, col2 = st.columns([3, 1])

with col1:
    brand = st.selectbox(
        "사이트 / 기관 선택",
        ["전체", "도로교통공단", "환경부", "경기도청"]
    )

with col2:
    keyword = st.text_input("검색")
    search_clicked = st.button("검색")

st.divider()

# -----------------------------
# FAQ 데이터 (4개)
# -----------------------------
faq_list = [
    (1, "충청북도 운전면허 시험장 위치?", "청주와 충주에 위치하고 있습니다."),
    (2, "경상북도 사고 다발 구역?", "KOSIS 교통사고 분석 시스템에서 확인하세요."),
    (3, "차종별 고속도로 통행료 기준?", "소형·중형·대형으로 구분됩니다."),
    (4, "어린이 보호구역 속도 제한?", "일반적으로 시속 30km 이하입니다."),
]

# -----------------------------
# 검색 버튼 눌렀을 때만 필터
# -----------------------------
if search_clicked and keyword:
    faq_list = [
        faq for faq in faq_list
        if keyword in faq[1] or keyword in faq[2]
    ]

# -----------------------------
# 열림 상태
# -----------------------------
if "open_q" not in st.session_state:
    st.session_state.open_q = None

# -----------------------------
# 스타일
# -----------------------------
st.markdown("""
<style>
.q-box {
    border: 1.5px solid #cfcfcf;
    border-radius: 10px;
    padding: 18px;
    margin-bottom: 8px;
    background-color: white;
    font-weight: 500;
}
.a-box {
    background-color: #dbe9ff;
    border-radius: 6px;
    padding: 18px;
    margin-bottom: 20px;
}
</style>
""", unsafe_allow_html=True)

# -----------------------------
# 출력
# -----------------------------
for faq_id, question, answer in faq_list:

    if st.button(
        f"Q. {question}",
        key=f"q_{faq_id}",
        use_container_width=True
    ):
        st.session_state.open_q = (
            None if st.session_state.open_q == faq_id else faq_id
        )

    if st.session_state.open_q == faq_id:
        st.markdown(
            f"<div class='a-box'>A. {answer}</div>",
            unsafe_allow_html=True
        )
